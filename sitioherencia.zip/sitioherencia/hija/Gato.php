<?php
require_once('./padre/Animal.php');
class Gato extends Animal{

    public function ProtectedDormir(){
        echo "<p>Gato duerme</p>";
        $this->dormir();
    }
}