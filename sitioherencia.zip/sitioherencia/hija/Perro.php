<?php
require_once('./padre/Animal.php');
class Perro extends Animal{

    public  function comer(){
        echo "<p>El perro, come huesos</p>";
    }

    public function ProtectedDormir(){
        echo "<p>Perro duerme</p>";
        $this->dormir();
    }
}